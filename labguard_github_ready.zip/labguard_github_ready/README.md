# LabGuard Personal Workspace Assistant

LabGuard is a hackathon prototype for a personal laboratory workspace safety assistant.

The system combines:
- Worker ID-based login simulation
- Personal workspace dashboard
- Live webcam feed
- YOLO/OpenCV APD detection
- Chemical barcode simulation
- Personal safety alerts
- Voice-command simulation buttons

## GitHub-Friendly Folder Structure

```text
labguard_github_ready/
│
├── backend/
│   └── app.py
│
├── frontend/
│   ├── templates/
│   │   └── index.html
│   │
│   └── static/
│       ├── css/
│       │   └── style.css
│       │
│       └── js/
│           └── app.js
│
├── models/
│   ├── yolov8n.pt
│   ├── Glasses.pt
│   └── Mask.pt
│
├── docs/
│   └── file_guide.md
│
├── requirements.txt
├── .gitignore
└── README.md
```

## What Each File Does

### `backend/app.py`
Runs the Flask server and connects the website to the YOLO/OpenCV webcam detection.

Main routes:
- `/` shows the website.
- `/video_feed` streams the annotated webcam feed.
- `/api/apd_status` gives APD detection results as JSON.

### `frontend/templates/index.html`
Contains only the HTML structure of the page.

Use this file to edit:
- page sections
- text labels
- buttons
- card structure

### `frontend/static/css/style.css`
Contains all styling.

Use this file to edit:
- colors
- fonts
- layout
- cards
- badges
- buttons
- camera display style

### `frontend/static/js/app.js`
Contains all frontend behavior.

Use this file to edit:
- worker login data
- procedure steps
- chemical list
- alerts
- camera/APD status update logic

### `models/`
Stores YOLO model files used by the backend.

## How to Run

Open this folder in VS Code.

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the app:

```bash
python backend/app.py
```

Open in browser:

```text
http://127.0.0.1:5000
```

## Important Notes for GitHub

The `.pt` model files may be large. If GitHub rejects them, use Git LFS or upload them separately.

To track large files with Git LFS:

```bash
git lfs install
git lfs track "*.pt"
git add .gitattributes
```
