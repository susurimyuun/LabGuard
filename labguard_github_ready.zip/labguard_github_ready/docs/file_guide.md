# File Guide

## If you want to change the UI design
Edit:

```text
frontend/static/css/style.css
```

Common things to customize:
- `:root` color variables
- `.card`
- `.btn-primary`
- `.workspace-view`
- `.badge`
- `body`

## If you want to change visible text or layout
Edit:

```text
frontend/templates/index.html
```

Common things to customize:
- Header title
- Section names
- Button labels
- Card order

## If you want to change worker data
Edit:

```text
frontend/static/js/app.js
```

Find:

```js
const workers = {
```

Inside that object, you can edit:
- names
- workspace numbers
- shifts
- assigned tasks
- chemical lists
- procedure steps

## If you want to change backend camera/model logic
Edit:

```text
backend/app.py
```

Common things to customize:
- YOLO model paths
- detection confidence
- camera source
- API response format
