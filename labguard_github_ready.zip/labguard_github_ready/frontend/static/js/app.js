/*
  LabGuard Frontend Logic
  -----------------------
  This file controls the website interactions:
  worker login, task loading, APD status display, chemical scan simulation,
  voice command simulation, and alert feed.
*/

const workers = {
      bryan: {
        name: "Bryan",
        initial: "B",
        workspace: "1",
        shift: "08:00 - 12:00",
        shortShift: "08-12",
        task: "Paracetamol Synthesis Preparation",
        access: "Research Assistant",
        chemicals: ["Acetic Anhydride", "Hydrochloric Acid"],
        procedure: [
          "Verify identity using lab ID card.",
          "Complete APD camera check before opening chemicals.",
          "Scan each chemical barcode before use.",
          "Follow the synthesis preparation checklist on the tablet.",
          "Submit result and end shift by rescanning ID card."
        ]
      },
      aisha: {
        name: "Aisha",
        initial: "A",
        workspace: "2",
        shift: "08:00 - 12:00",
        shortShift: "08-12",
        task: "Chemical Inventory Verification",
        access: "Lab Inventory Officer",
        chemicals: ["Ethanol", "Sodium Hydroxide"],
        procedure: [
          "Verify identity using lab ID card.",
          "Run APD scan before handling inventory.",
          "Scan chemical barcode and match it with database record.",
          "Flag expired or misplaced chemicals.",
          "Submit inventory report before ending shift."
        ]
      },
      daniel: {
        name: "Daniel",
        initial: "D",
        workspace: "3",
        shift: "10:00 - 14:00",
        shortShift: "10-14",
        task: "Acid-Base Reaction Test",
        access: "Chemistry Analyst",
        chemicals: ["Hydrochloric Acid", "Sodium Hydroxide"],
        procedure: [
          "Verify identity using lab ID card.",
          "Complete APD scan and confirm eyewear protection.",
          "Scan acid and base containers before experiment.",
          "Start reaction test only after compatibility approval.",
          "Record observation and confirm workspace shutdown."
        ]
      }
    };

    let currentWorker = null;
    let scannedChemicals = [];
    let alerts = [];
    let cameraStarted = false;

    function updateTime() {
      const now = new Date();
      document.getElementById("currentTime").textContent = now.toLocaleString();
    }

    function loginWorker(workerId) {
      currentWorker = workers[workerId];
      scannedChemicals = [];
      alerts = [`${currentWorker.name} verified. Personal workspace loaded.`];

      document.getElementById("loginPanel").classList.add("hidden");
      ["profilePanel", "statusPanel", "cameraPanel", "taskPanel", "apdPanel", "chemicalPanel", "assistantPanel", "alertPanel"].forEach(id => {
        document.getElementById(id).classList.remove("hidden");
      });

      document.getElementById("welcomeTitle").textContent = `Welcome, ${currentWorker.name}`;
      document.getElementById("profileAvatar").textContent = currentWorker.initial;
      document.getElementById("profileName").textContent = currentWorker.name;
      document.getElementById("profileMeta").textContent = `Workspace ${currentWorker.workspace} • ${currentWorker.shift} • ${currentWorker.access}`;
      document.getElementById("workspaceStat").textContent = currentWorker.workspace;
      document.getElementById("apdStat").textContent = "Waiting";
      document.getElementById("shiftStat").textContent = currentWorker.shortShift;
      document.getElementById("taskTitle").textContent = currentWorker.task;

      renderProcedure();
      renderChemicalButtons();
      renderAlerts();

      document.getElementById("chemicalStatus").textContent = "No chemical scanned.";
      document.getElementById("apdResult").textContent = "Waiting for APD scan.";
      setBadge("personBadge", "Person: Waiting", "neutral");
      setBadge("glassesBadge", "Glasses: Waiting", "neutral");
      setBadge("maskBadge", "Mask: Waiting", "neutral");
    }

    function logoutWorker() {
      if (currentWorker) {
        alert(`${currentWorker.name}'s shift has ended safely.`);
      }

      currentWorker = null;
      scannedChemicals = [];
      alerts = [];
      cameraStarted = false;

      document.getElementById("workspaceView").innerHTML = `<div class="camera-placeholder" id="cameraPlaceholder">Click “Start Live Camera” to connect YOLO APD detection.</div>`;

      document.getElementById("loginPanel").classList.remove("hidden");
      ["profilePanel", "statusPanel", "cameraPanel", "taskPanel", "apdPanel", "chemicalPanel", "assistantPanel", "alertPanel"].forEach(id => {
        document.getElementById(id).classList.add("hidden");
      });
    }

    function renderProcedure() {
      const procedureList = document.getElementById("procedureList");
      procedureList.innerHTML = "";

      currentWorker.procedure.forEach((step, index) => {
        procedureList.innerHTML += `
          <div class="procedure-step">
            <strong>Step ${index + 1}</strong>
            <p class="muted">${step}</p>
          </div>
        `;
      });
    }

    function renderChemicalButtons() {
      const chemicalButtons = document.getElementById("chemicalButtons");
      chemicalButtons.innerHTML = "";

      currentWorker.chemicals.forEach(chemical => {
        chemicalButtons.innerHTML += `<button class="btn-primary" onclick="scanChemical('${chemical}')">Scan ${chemical}</button>`;
      });
    }

    function startLiveCamera() {
      if (!cameraStarted) {
        document.getElementById("workspaceView").innerHTML = `<img src="/video_feed" alt="Live YOLO APD Camera Feed">`;
        cameraStarted = true;
        addAlert("Live YOLO APD camera feed started.");
        setInterval(refreshAPDStatus, 1500);
      }
    }

    async function refreshAPDStatus() {
      try {
        const response = await fetch("/api/apd_status");
        const data = await response.json();

        document.getElementById("apdStat").textContent = data.apd_camera_status || "Waiting";

        setBadge("personBadge", `Person: ${data.person_detected ? "Detected" : "Missing"}`, data.person_detected ? "safe" : "warning");
        setBadge("glassesBadge", `Glasses: ${data.glasses_detected ? "Detected" : "Missing"}`, data.glasses_detected ? "safe" : "warning");
        setBadge("maskBadge", `Mask: ${data.mask_detected ? "Detected" : "Missing"}`, data.mask_detected ? "safe" : "warning");

        if (data.apd_camera_status === "Approved") {
          document.getElementById("apdResult").textContent = "✅ Camera APD approved. You may continue your task.";
        } else if (data.camera_on) {
          document.getElementById("apdResult").textContent = "⚠️ Camera APD incomplete. Please check mask/glasses.";
        }
      } catch (error) {
        document.getElementById("apdStat").textContent = "Offline";
      }
    }

    function setBadge(id, text, statusClass) {
      const badge = document.getElementById(id);
      badge.textContent = text;
      badge.className = `badge ${statusClass}`;
    }

    function checkAPDManual() {
      const labCoat = document.getElementById("labCoat").checked;
      const gloves = document.getElementById("gloves").checked;
      const goggles = document.getElementById("goggles").checked;
      const mask = document.getElementById("mask").checked;

      if (labCoat && gloves && goggles && mask) {
        document.getElementById("apdResult").textContent = "✅ Manual APD approved. You may continue your task.";
        document.getElementById("apdStat").textContent = "Approved";
        addAlert("Manual APD checklist approved.");
      } else {
        document.getElementById("apdResult").textContent = "❌ Manual APD incomplete. Please complete protective equipment before continuing.";
        document.getElementById("apdStat").textContent = "Failed";
        addAlert("Manual APD checklist failed. Missing required equipment.");
      }
    }

    function scanChemical(name) {
      if (!scannedChemicals.includes(name)) {
        scannedChemicals.push(name);
      }

      document.getElementById("chemicalStatus").textContent = scannedChemicals.join(", ");
      addAlert(`${name} barcode scanned for your assigned task.`);
    }

    function checkChemicalRisk() {
      if (scannedChemicals.includes("Acetic Anhydride") && scannedChemicals.includes("Hydrochloric Acid")) {
        document.getElementById("chemicalStatus").innerHTML = `${scannedChemicals.join(", ")}<br>🚨 Compatibility warning. Supervisor approval required.`;
        addAlert("Chemical compatibility warning detected. Supervisor approval required.");
      } else if (scannedChemicals.length === 0) {
        document.getElementById("chemicalStatus").textContent = "No chemical scanned.";
      } else {
        document.getElementById("chemicalStatus").innerHTML = `${scannedChemicals.join(", ")}<br>✅ No major compatibility issue detected in prototype database.`;
        addAlert("Chemical compatibility check completed for your workspace.");
      }
    }

    function voiceCommand(command) {
      const output = document.getElementById("voiceOutput");

      if (command === "show procedure") {
        output.textContent = currentWorker.procedure.join(" → ");
      } else if (command === "show hazard") {
        output.textContent = "Hazard info: Follow APD requirements, avoid inhalation, scan all chemical barcodes, and request supervisor approval for flagged combinations.";
      } else if (command === "call supervisor") {
        output.textContent = "🚨 Supervisor has been notified for your workspace.";
        addAlert("Supervisor assistance requested from your workspace.");
      }
    }

    function simulateNoMovement() {
      addAlert("No movement detected for 60 minutes. Stretch reminder activated. Supervisor notified if no response.");
    }

    function simulateGasLeak() {
      addAlert("Possible gas leak detected near your workspace. Emergency ventilation procedure activated.");
    }

    function clearAlerts() {
      alerts = [];
      renderAlerts();
    }

    function addAlert(message) {
      alerts.unshift(message);
      renderAlerts();
    }

    function renderAlerts() {
      const alertBox = document.getElementById("alerts");
      alertBox.innerHTML = "";

      if (alerts.length === 0) {
        alertBox.innerHTML = `<div class="alert-item"><p>No personal alerts at the moment.</p></div>`;
        return;
      }

      alerts.forEach(alert => {
        alertBox.innerHTML += `<div class="alert-item"><p>⚠️ ${alert}</p></div>`;
      });
    }

    updateTime();
    setInterval(updateTime, 1000);
