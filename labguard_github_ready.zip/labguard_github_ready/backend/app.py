from flask import Flask, render_template, Response, jsonify
import cv2
import time
from pathlib import Path
from ultralytics import YOLO

app = Flask(__name__, template_folder="../frontend/templates", static_folder="../frontend/static")

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR.parent / "models"

# Your friend's YOLO files, moved into /models
PERSON_MODEL = MODEL_DIR / "yolov8n.pt"
GLASSES_MODEL = MODEL_DIR / "Glasses.pt"
MASK_MODEL = MODEL_DIR / "Mask.pt"

# Load models once when the server starts.
# This follows your friend's logic: YOLO model for general detection,
# plus separate trained models for glasses and mask.
model_person = YOLO(str(PERSON_MODEL))
model_glasses = YOLO(str(GLASSES_MODEL))
model_mask = YOLO(str(MASK_MODEL))

latest_status = {
    "camera_on": False,
    "person_detected": False,
    "glasses_detected": False,
    "mask_detected": False,
    "apd_camera_status": "Waiting",
    "last_update": None
}

def has_person(results):
    """Check whether YOLOv8n detected a person class."""
    if not results or len(results) == 0:
        return False

    result = results[0]
    if result.boxes is None:
        return False

    for box in result.boxes:
        class_id = int(box.cls[0])
        class_name = result.names.get(class_id, "")
        if class_name == "person":
            return True

    return False

def has_any_detection(results):
    """For custom APD models: if any box appears, assume item is detected."""
    if not results or len(results) == 0:
        return False

    result = results[0]
    return result.boxes is not None and len(result.boxes) > 0

def generate_frames():
    """
    Opens webcam and streams annotated frames to the website.
    Press Ctrl+C in terminal to stop the Flask server.
    """
    cap = cv2.VideoCapture(0)

    latest_status["camera_on"] = cap.isOpened()

    while cap.isOpened():
        success, frame = cap.read()

        if not success:
            break

        # Same detection flow as your friend's coba_bryan.py
        results_person = model_person(frame, conf=0.5, imgsz=640)
        results_glasses = model_glasses(frame, conf=0.5, imgsz=640)
        results_mask = model_mask(frame, conf=0.1, imgsz=640)

        # Draw bounding boxes from all models into one frame
        annotated_frame = results_person[0].plot()
        annotated_frame = results_glasses[0].plot(img=annotated_frame)
        annotated_frame = results_mask[0].plot(img=annotated_frame)

        # Update status for the website UI
        person_detected = has_person(results_person)
        glasses_detected = has_any_detection(results_glasses)
        mask_detected = has_any_detection(results_mask)

        latest_status.update({
            "camera_on": True,
            "person_detected": person_detected,
            "glasses_detected": glasses_detected,
            "mask_detected": mask_detected,
            "apd_camera_status": "Approved" if person_detected and glasses_detected and mask_detected else "Incomplete",
            "last_update": time.strftime("%H:%M:%S")
        })

        # Convert frame to JPG for browser streaming
        ret, buffer = cv2.imencode(".jpg", annotated_frame)
        if not ret:
            continue

        frame_bytes = buffer.tobytes()

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n" + frame_bytes + b"\r\n"
        )

    latest_status["camera_on"] = False
    cap.release()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/video_feed")
def video_feed():
    return Response(generate_frames(), mimetype="multipart/x-mixed-replace; boundary=frame")

@app.route("/api/apd_status")
def apd_status():
    return jsonify(latest_status)

if __name__ == "__main__":
    # Open http://127.0.0.1:5000 in your browser.
    app.run(host="127.0.0.1", port=5000, debug=True)
